package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver{
    private int deviceCount = 0;
    @Override
    public void update(SystemMonitor monitor) {
        SystemState lastSystemState = monitor.getLastSystemState();
        int newDeviceCount = lastSystemState.getUsbDevices();
        if(newDeviceCount != deviceCount)
        {
            deviceCount = newDeviceCount;
            System.out.println(String.format("USB devices: %d", newDeviceCount));
        }

    }
}
