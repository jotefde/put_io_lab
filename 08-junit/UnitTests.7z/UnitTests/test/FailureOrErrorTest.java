import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;

import static org.junit.jupiter.api.Assertions.*;

public class FailureOrErrorTest {

    @Test
    public void test1()
    {
        assertEquals("Tak", "Nie");
    }
    @Test
    public void test2() throws Exception {
        throw new Exception("Dowolny wjatek");
    }

    @Test
    public void test3()
    {
        try
        {
            assertEquals("Nie", "Tak");
        }
        catch(AssertionFailedError e)
        {
            e.printStackTrace();
        }
    }
}
