package put.io.testing.audiobooks;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import put.io.testing.junit.Calculator;

import static org.junit.jupiter.api.Assertions.*;

class AudiobookPriceCalculatorTest {

    AudiobookPriceCalculator calculator;

    // Przy BeforeAll będzie działać tak samo,
    // ponieważ wyniki metod add, multiply i testAddPositiveNumbers są niezależne od instancji
    @BeforeEach
    void setUp() {
        calculator = new AudiobookPriceCalculator();
    }

    @Test
    void calculate() {
        assertThrows(NullPointerException.class,
                () -> calculator.calculate(null, new Audiobook("Test", 1.00)),
                "Customer is null");
        assertThrows(NullPointerException.class,
                () -> calculator.calculate(new Customer("Test", Customer.LoyaltyLevel.STANDARD, false), null),
                "Audiobook is null");
    }
}