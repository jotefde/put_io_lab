package put.io.testing.junit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {
    Calculator calculator;

    // Przy BeforeAll będzie działać tak samo,
    // ponieważ wyniki metod add, multiply i testAddPositiveNumbers są niezależne od instancji
    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }
    @Test
    void testAdd() {
        assertEquals(9, calculator.add(4, 5),
                "Regular add should work");
        assertEquals(-3, calculator.add(-3, 0),
                "Regular add should work");
    }

    @Test
    void testMultiply() {
        assertEquals(20, calculator.multiply(4, 5),
                "Regular multiply should work");
        assertEquals(0, calculator.multiply(-3, 0),
                "Regular multiply should work");
    }

    @Test
    void testAddPositiveNumbers()
    {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class,
                () -> calculator.addPositiveNumbers(-1, 2),
                "IllegalArgumentException was expected");
        assertEquals("The arguments must be positive", thrown.getMessage());
    }
}